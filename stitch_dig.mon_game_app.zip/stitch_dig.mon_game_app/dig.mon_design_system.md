---
name: "DIG.MON Arcade"
description: "Sistema de diseño retro-arcade pixelado con fondo amarillo vibrante, tipografía estilo Minecraft y alto contraste."
---

## Overview

**DIG.MON Arcade** combina la energía nostálgica de las consolas portátiles y los juegos de bloques con el universo clásico de compañeros digitales. Diseñado para jugadores jóvenes y fans de lo retro, el sistema prioriza la legibilidad instantánea, botones táctiles con relieve físico y una paleta dominada por el amarillo arcade, tinta negra profunda y acentos en naranja y azul eléctrico.

El estilo visual es **Retro / Pixel Arcade**: bordes sólidos bien definidos, sombras duras sin desenfoque, esquinas rectas o mínimamente biseladas y una jerarquía clara que centra toda la atención en los personajes y el botón principal de inicio.

## Colors

El amarillo vibrante (`arcade-yellow`) actúa como superficie principal del lienzo, evocando energía y visibilidad inmediata. El azul (`primary`) y el naranja (`secondary`) representan a los compañeros digitales y se reservan para acciones principales y destacados, siempre emparejados con texto de alto contraste.

```yaml
colors:
  arcade-yellow: "#FFD400"
  digivice-orange: "#FF6B00"
  gabumon-blue: "#005CBA"
  ink-black: "#1A1600"
  light:
    primary: "#005CBA"
    on-primary: "#FFFFFF"
    primary-container: "#D7E3FF"
    on-primary-container: "#001B3E"
    secondary: "#FF6B00"
    on-secondary: "#1A0800"
    secondary-container: "#FFDBCC"
    on-secondary-container: "#351000"
    surface: "#FFD400"
    on-surface: "#1A1600"
    surface-container: "#FFF0C6"
    surface-container-low: "#FFE177"
    surface-container-high: "#FFFBFF"
    on-surface-variant: "#3B2F00"
    outline: "#1A1600"
    outline-variant: "#715D00"
    error: "#BA1A1A"
    on-error: "#FFFFFF"
  dark:
    primary: "#7BABFF"
    on-primary: "#001B3E"
    primary-container: "#00458E"
    on-primary-container: "#D7E3FF"
    secondary: "#FF8C52"
    on-secondary: "#351000"
    secondary-container: "#7A3000"
    on-secondary-container: "#FFDBCC"
    surface: "#1A1600"
    on-surface: "#FFE177"
    surface-container: "#231B00"
    surface-container-low: "#201C02"
    surface-container-high: "#3B2F00"
    on-surface-variant: "#EDE3B7"
    outline: "#FFD400"
    outline-variant: "#715D00"
    error: "#FFB4AB"
    on-error: "#690005"
```

## Typography

Para lograr el aspecto de bloques y videojuegos clásicos estilo Minecraft, **Press Start 2P** encabeza todos los títulos, logotipos y botones de acción principales. **Poppins** aporta legibilidad limpia en textos descriptivos y subtítulos, mientras que **Spline Sans Mono** se utiliza para contadores, niveles y datos tabulares.

```yaml
typography:
  display-lg:
    fontFamily: "Press Start 2P"
    fontSize: 40px
    fontWeight: 400
    lineHeight: 52px
    letterSpacing: 1px
  display-lg-mobile:
    fontFamily: "Press Start 2P"
    fontSize: 28px
    fontWeight: 400
    lineHeight: 36px
    letterSpacing: 0.5px
  headline-lg:
    fontFamily: "Press Start 2P"
    fontSize: 24px
    fontWeight: 400
    lineHeight: 34px
    letterSpacing: 0.5px
  headline-lg-mobile:
    fontFamily: "Press Start 2P"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 26px
    letterSpacing: 0.5px
  title-lg:
    fontFamily: "Press Start 2P"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 24px
    letterSpacing: 0.25px
  title-md:
    fontFamily: "Poppins"
    fontSize: 16px
    fontWeight: 700
    lineHeight: 22px
    letterSpacing: 0px
  body-lg:
    fontFamily: "Poppins"
    fontSize: 16px
    fontWeight: 500
    lineHeight: 24px
    letterSpacing: 0px
  body-md:
    fontFamily: "Poppins"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 20px
    letterSpacing: 0px
  label-lg:
    fontFamily: "Press Start 2P"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 20px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: "Poppins"
    fontSize: 12px
    fontWeight: 700
    lineHeight: 16px
    letterSpacing: 0.5px
  mono-md:
    fontFamily: "Spline Sans Mono"
    fontSize: 13px
    fontWeight: 600
    lineHeight: 18px
    letterSpacing: 0px
```

## Layout & Spacing

El diseño sigue una cuadrícula fluida centrada en móvil (`390px`) con márgenes de `24px` y una escala estricta de `4px`/`8px`. En la pantalla de inicio, la composición vertical equilibra el logotipo superior, la ilustración central protagonista y el bloque de acción inferior con amplio aire amarillo alrededor.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  section: 40px
  page-margin: 24px
```

## Elevation & Depth

La jerarquía visual se construye mediante **bordes sólidos de 3px–4px** en tinta negra (`outline`) y **sombras duras desplazadas** (`4px 4px 0px #1A1600`, sin desenfoque). Al presionar un botón, el desplazamiento de la sombra se reduce para simular un interruptor mecánico de consola portátil. Evitar desenfoques de fondo o transparencias difusas.

## Shapes

La geometría es intencionalmente angular y en bloques para reforzar la estética pixelada. Los contenedores principales usan esquinas nítidas (`4px` o `0px`), mientras que las insignias pequeñas pueden usar `8px`.

```yaml
rounded:
  none: 0px
  sm: 2px
  DEFAULT: 4px
  md: 8px
  lg: 12px
  full: 9999px
```

## Motion & Micro-interaction

Las transiciones son rápidas y mecánicas, emulando la respuesta inmediata de un botón arcade. Solo se animan `transform`, `opacity` y color; nunca propiedades de geometría.

```yaml
motion:
  button-press:
    duration: 80ms
    delay: 0ms
    timingFunction: ease-out
  surface-enter:
    duration: 200ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
```

## Voice & Content Strategy

- **Tono de voz:** Directo, entusiasta y de aventura arcade ("¡A la aventura!", "Elige tu compañero").
- **Mayúsculas:** Títulos principales y botones de acción arcade en mayúsculas (`DIG.MON`, `INICIO`) para aprovechar la geometría cuadrada de la fuente pixelada; subtítulos en tipo oración.
- **Etiquetas de acción:** Cortas, de una o dos palabras (`INICIO`, `CONTINUAR`, `OPCIONES`).

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Button** → `@components/button.html` — `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html` — `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Typography** → `@components/typography.html` — `typography-display`, `typography-body`, `typography-label`
